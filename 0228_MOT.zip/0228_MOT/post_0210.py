import numpy as np
import pandas as pd 
import os 
from tqdm import tqdm
from scipy.interpolate import CubicSpline  # 3次样条插值CubicSpline

def post_process(objs_dict, out_file, freq = 10, displace_thr1 = 2., displace_thr2 = 4.,displace_r_thr = 0.5):
    column_names = ['frame','ts','UID','type','h','w','l','x','y','z','yaw','conf']
    outs = pd.DataFrame(columns = column_names)
    ts_step = 1000/freq
    for key,value in objs_dict.items():
        data_df = pd.DataFrame(value,columns = column_names)
        ex_df = pd.DataFrame(columns = column_names)
         
        if key == -1: 
            data_df['vx'] = 0.
            data_df['vy'] = 0.
            for i in range(len(data_df)-1): 
                data_df.iloc[i,-2] = 1000 * (data_df['x'].iloc[i+1] - data_df['x'].iloc[i])/(data_df['ts'].iloc[i+1] - data_df['ts'].iloc[i])
                data_df.iloc[i,-1] = 1000 * (data_df['y'].iloc[i+1] - data_df['y'].iloc[i])/(data_df['ts'].iloc[i+1] - data_df['ts'].iloc[i])
            if len(outs) == 0:
                outs = data_df.copy()
            else:
                outs = pd.concat([outs,data_df])
            continue

        if len(data_df) <=3: 
            continue

        # 0210, 判断物体静止
        begin = data_df['frame'].iloc[0]
        end = data_df['frame'].iloc[-1]
        #displace1 = np.linalg.norm([data_df['x'].max()-data_df['x'].min(),data_df['y'].max()-data_df['y'].min()])/((end-begin+1)/freq)
        #displace2 = np.linalg.norm([data_df['x'].max()-data_df['x'].min(),data_df['y'].max()-data_df['y'].min()])
        displace1 = np.linalg.norm([data_df['x'].quantile(.9)-data_df['x'].quantile(.1),data_df['y'].quantile(.9)-data_df['y'].quantile(.1)])/((end-begin+1)/freq)
        displace2 = np.linalg.norm([data_df['x'].quantile(.9)-data_df['x'].quantile(.1),data_df['y'].quantile(.9)-data_df['y'].quantile(.1)])
        ##displace2 = np.linalg.norm(data_df[['x','y']]-[data_df['x'].median(),data_df['y'].median()],axis=1)
        ##displace_ratio = len(displace2[displace2 <= displace_thr])/len(displace2)
        if displace1 <= displace_thr1 or displace2 <= displace_thr2:
        #if displace1 <= displace_thr or displace_ratio >= displace_r_thr: 
        #if displace_ratio >= displace_r_thr:
            ex_df = pd.DataFrame([[begin + j
                    , int(data_df['ts'].iloc[0]+ ts_step * j)
                    , int(data_df['UID'].iloc[0])
                    , data_df['type'].iloc[0]
                    , data_df['h'].median(), data_df['w'].median(), data_df['l'].median()
                    , data_df['x'].median(), data_df['y'].median(), data_df['z'].median(), data_df['yaw'].median()
                    , -1] for j in range(end - begin + 1)],columns=column_names)
            ex_df['vx'] = 0.
            ex_df['vy'] = 0.
            if len(outs) == 0:
                outs = ex_df.copy()
            else:
                outs = pd.concat([outs,ex_df])
            continue
        #else: 
            #print(key,displace1,displace2)
        
        ## 0212,调整动态物体的航向角度
        # traj_vect = data_df[['x','y']].iloc[1:].values-data_df[['x','y']].iloc[:-1].values
        # traj_vect = np.append(traj_vect,[traj_vect[-1]],axis=0)
        # traj_vect = traj_vect/(np.linalg.norm(traj_vect,axis=1))[:,None]
        # obj_yaw = np.concatenate((np.cos(data_df['yaw'].values)[:,None],np.sin(data_df['yaw'].values)[:,None]),axis=1)
        # ori = (traj_vect*obj_yaw).sum(axis=1)
        # #yaw_update = data_df['yaw'].values
        # #yaw_update[ori<np.sqrt(3)/2] = np.arctan2(traj_vect[ori<np.sqrt(3)/2][:,1],traj_vect[ori<np.sqrt(3)/2][:,0])
        # #yaw_update[ori<0] = yaw_update[ori<0]%(2*np.pi) - np.pi
        # yaw_update = np.arctan2(traj_vect[:,1],traj_vect[:,0])
        # data_df['yaw'] = yaw_update

        # 补帧
        begin = data_df['frame'].iloc[0]
        end = data_df['frame'].iloc[-1]
        temp = pd.DataFrame([[begin + j
                , int(data_df['ts'].iloc[0]+ ts_step * j)
                , int(data_df['UID'].iloc[0])
                , data_df['type'].iloc[0]
                , data_df['h'].mean(), data_df['w'].mean(), data_df['l'].mean()
                , np.NaN, np.NaN, np.NaN, np.NaN, -1] for j in range(end - begin + 1)],columns=column_names)

        t_axis = data_df['frame'].values - data_df['frame'].iloc[0]
        x_axis = data_df['x'].values
        y_axis = data_df['y'].values
        z_axis = data_df['z'].values

        # coefficients = np.polyfit(t_axis,x_axis,3)
        # polynomial = np.poly1d(coefficients)
        # x_fit = polynomial([j for j in range(end - begin + 1)])
        # temp['x'] = x_fit
        

        # coefficients = np.polyfit(t_axis,y_axis,3)
        # polynomial = np.poly1d(coefficients)
        # y_fit = polynomial([j for j in range(end - begin + 1)])
        # temp['y'] = y_fit
        

        # coefficients = np.polyfit(t_axis,z_axis,3)
        # polynomial = np.poly1d(coefficients)
        # z_fit = polynomial([j for j in range(end - begin + 1)])
        # temp['z'] = z_fit
        
        cs = CubicSpline(t_axis, x_axis)
        #temp['x'] = cs([j for j in range(end - begin + 1)])
        temp['x'] = moving_average(cs([j for j in range(end - begin + 1)]))
        x_deriv = cs.derivative()([j for j in range(end - begin + 1)])
        cs = CubicSpline(t_axis, y_axis)
        #temp['y'] = cs([j for j in range(end - begin + 1)])
        temp['y'] = moving_average(cs([j for j in range(end - begin + 1)]))
        y_deriv = cs.derivative()([j for j in range(end - begin + 1)])
        cs = CubicSpline(t_axis, z_axis)
        #temp['z'] = cs([j for j in range(end - begin + 1)])
        temp['z'] = moving_average(cs([j for j in range(end - begin + 1)]))

        traj_vect = temp[['x','y']].iloc[1:].values-temp[['x','y']].iloc[:-1].values
        traj_vect = np.append(traj_vect,[traj_vect[-1]],axis=0)
        #traj_vect = np.concatenate([x_deriv[:,None],y_deriv[:,None]],axis=1)
        traj_vect = traj_vect/(np.linalg.norm(traj_vect,axis=1)+1e-3)[:,None]
        obj_yaw = np.concatenate((np.cos(data_df['yaw'].values)[:,None],np.sin(data_df['yaw'].values)[:,None]),axis=1)
        ori = (traj_vect[[j in set(data_df['frame']) for j in temp['frame']]]*obj_yaw).sum(axis=1)
        yaw_update = np.arctan2(traj_vect[:,1],traj_vect[:,0])
        yaw_update[[j in set(data_df['frame']) for j in temp['frame']]][ori>np.sqrt(3)/2]=data_df[ori>np.sqrt(3)/2]['yaw']
        temp['yaw'] = yaw_update
        
        # 如果yaw过大，判断是静止物体抖动导致
        yaw_max = abs(temp['yaw'].iloc[1:].values-temp['yaw'].iloc[:-1].values)%(2*np.pi)
        yaw_max = np.max([min(j,2*np.pi-j) for j in yaw_max])*freq
        if yaw_max > 5 and data_df['conf'].median() > 5:
            print(key,yaw_max)
            temp['x'] = data_df['x'].median()
            temp['y'] = data_df['y'].median()
            temp['yaw'] = data_df['yaw'].median()
            #continue

        temp['vx'] = 0.
        temp['vy'] = 0.
        for i in range(len(temp)-1): 
            temp.iloc[i,-2] = 1000 * (temp['x'].iloc[i+1] - temp['x'].iloc[i])/(temp['ts'].iloc[i+1] - temp['ts'].iloc[i])
            temp.iloc[i,-1] = 1000 * (temp['y'].iloc[i+1] - temp['y'].iloc[i])/(temp['ts'].iloc[i+1] - temp['ts'].iloc[i])
        if len(outs) == 0:
            outs = temp.copy()
        else:
            outs = pd.concat([outs,temp])

    with open(out_file,'w') as f: 
        for out in outs.values: 
            for element in out: 
                f.write(str(element) + ' ')
            f.write('\n')


def moving_average(arr,window_size=10):
    data = pd.Series(arr)
    window_size = window_size
    result = data.rolling(window=window_size,min_periods= 1,center=True).mean()
    return result.values
        