import matplotlib
import matplotlib.pyplot as plt 
import numpy as np 
from tqdm import tqdm
import glob
import os
import json
import cv2

from utils.gt_utils import compute_box_3d,read_label,draw_gt_boxes3d,compute_o2w,compute_o2w_from_c2w
from utils.camera_utils import inverse_rigid_trans
from run_tracking_customized import draw_projected_box3d,Object3d_simple

# 车辆坐标系下的bev图像
# from zl,相机坐标系,增加相机转车辆步骤;
# from ml,车辆坐标系,无需旋转;

class Object3d_ego(object):
    """ 3d object label """

    def __init__(self, data):
        self.type = 'Ego'  # 'Car', 'Pedestrian', ...
        self.frame = data[0]  
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.ry = data[4]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.t = (0,0,0)
        self.confidence = -1
        self.uid = -1

def plotBEV(file,boxes,border,lanes):
    fig = plt.figure(dpi=500,figsize=(5,2))
    axes = plt.gca()
    #fig, axes = plt.subplots(dpi=500)
    axes.set_title('Frame:{}'.format(file))
    axes.set_aspect('equal', adjustable='box')
    axes.set_xlim([border[0]-5, border[1]+5])
    #axes.set_xlim([-2800, -2600])
    axes.set_ylim([border[2]-5, border[3]+5])
    for box,btype,uid in boxes: 
        if btype == 'Ego': 
            clr = 'red'
        elif btype in ["Car","Van"]: 
            clr = 'blue'
        else: 
            clr = 'green'
        rect = matplotlib.patches.Polygon(box[:4,:2], closed=True,zorder=1,fill=False,color=clr)
        axes.add_patch(rect)
        axes.plot(box[4:6,0],box[4:6,1],color='black',linewidth=.5)
        axes.text(np.mean(box[:4,0]),np.mean(box[:4,1])-0.5,str(int(uid)),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    
    try:
        for lane in lanes:
            locations = np.array(lane['xyz'])
            axes.plot(locations[:,1],-locations[:,0],color = 'green',linewidth=.5)
            axes.text(locations[-1,1]+1,-locations[-1,0],str(int(lane['lane_id'])),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    except:
        for lane,lid in lanes:
            axes.plot(lane[:,0],lane[:,1],color = 'green',linewidth=.5)
            axes.text(lane[-1,0]+1,lane[-1,1],str(int(lid)),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    return fig

def load_json_file(file_path):
    json_lines = []
    with open(file_path, 'r') as file:
        for line in file:
            # print("line", line)
            try:
                # 尝试逐行解析 JSON 对象
                lane_data = json.loads(line.strip())
                json_lines.append(lane_data)
            except json.JSONDecodeError:
                # 跳过格式错误的行
                continue
    return json_lines

def show_2d_box(data_dir,fig_dir,bbox_det_dir,save_dir):
    json_file = glob.glob(os.path.join(data_dir, '*.json'))
    infos = load_json_file(json_file[0])
    # obj det
    fov_dir = os.path.join(save_dir,'FOV')
    if not os.path.exists(fov_dir):
        os.mkdir(fov_dir)
    images = sorted(glob.glob(os.path.join(fig_dir, '*.png')))
    bboxes = sorted(glob.glob(os.path.join(bbox_det_dir, '*.txt')))
    n=len(images)
    for i in tqdm(range(n)): 
        objects = read_label(bboxes[i])
        img = cv2.imread(images[i])
        for obj in objects: 
            if obj.type not in ["Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),0,np.sin(obj.ry),obj.t[0]]
                        ,[0,1,0,obj.t[1]]
                        ,[-np.sin(obj.ry),0,np.cos(obj.ry),obj.t[2]]])
            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2, -l / 2, -l / 2]
            y_corners = [0, 0, 0, 0
                            , -h, -h, -h, -h]
            z_corners = [w / 2, -w / 2, -w / 2, w / 2            
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            pts_3d_extend = np.hstack((box3d_pts_3d_world, np.ones((8, 1))))
            if min(pts_3d_extend[:,2]) < 1e-6: 
                continue
            pts_2d = np.dot(box3d_pts_3d_world, np.transpose(np.array(
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                infos[i]['camera_intrinsic'][0]
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]

            img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
            #cv2.rectangle(img, (int(obj.box2d[0]),int(obj.box2d[1])), (int(obj.box2d[2]),int(obj.box2d[3])), (0, 255, 0), 2)
            #cv2.putText(img, 'ry:{:.2f}'.format(obj.ry), (int(pts_2d[0,0]),int(pts_2d[0,1])), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(255,255,255), thickness=2)
        cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)
    print("2D detection results completed...")

def fov_w(data_dir,fig_dir,line_label_dir,save_dir): 
    # obj trc and lane det
    json_file = glob.glob(os.path.join(data_dir, '*.json'))
    infos = load_json_file(json_file[0])

    with open(line_label_dir,'r') as f:
        lane_labels = json.load(f) 
    # check parameter files and lane files
    assert len(infos) == len(lane_labels),'Length of param files do not match lane detection files...'
    for i in range(len(infos)): 
        assert (lane_labels[i]['file_path'].split('/'))[-1] == infos[i]['filename']\
        , 'Name of param files do not match lane detection files with {} and {}...'.format((lane_labels[i]['file_path'].split('/'))[-1],infos[i]['filename'])
    print('Lane detection files check completed...')
    
    boxes_all = []
    lanes_all = []
    n = len(infos)
    #n =1 
    for i in range(n):
        lines = [line.rstrip() for line in open('./output_post.txt')]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(i)]
        
        boxes = []
        v2w = np.array(infos[i]['v2w'])
        v2w = np.concatenate((v2w,np.array([[0,0,0,1]])),axis=0)
        
        lanes = []
        for lane in lane_labels[i]['lane_lines']: 
            temp = np.array(lane['xyz'])
            #temp[:,0],temp[:,1] = temp[:,1],-temp[:,0]
            temp = np.concatenate((temp,np.ones((temp.shape[0],1))),axis=1)
            c2v = np.array(infos[i]['c2v'])
            c2v = np.array([[9.99991775e-01, -4.02539017e-03, 4.96265061e-04, 0.00000000e+00],
         [-4.45399714e-04, 1.26271973e-02, 9.99920175e-01, 0.00000000e+00],
         [-4.03133528e-03, -9.99912171e-01, 1.26253005e-02, 2.11585277e+00]])
            c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2c = inverse_rigid_trans(c2v)
            v2c[3,3] = 1
            temp = temp @ np.transpose(v2c)
            lanes.append((temp[:,:3],lane['lane_id'])) 

        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:,:3],obj.type,obj.uid)) 
        lanes_all.append(lanes) 
        boxes_all.append(boxes)

    fov_dir = os.path.join(save_dir,'FOV_all')
    if not os.path.exists(fov_dir):
        os.mkdir(fov_dir)
    images = glob.glob(os.path.join(fig_dir, '*.jpg'))
    images = sorted(images)
    for i in tqdm(range(n)): 
        img = cv2.imread(images[i])
        c2v = np.array(infos[i]['c2v'])
        c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
        v2w = np.array(infos[i]['v2w'])
        v2w = np.concatenate((v2w,np.array([[0,0,0,1]])),axis=0)
        c2w = v2w @ c2v

        for box,btype,uid in boxes_all[i]: 
            if btype not in ["Car","Van","Cyclist"]:
                continue
            pts_3d_extend = np.hstack((box[[0,1,2,3,7,8,9,10],:], np.ones((8, 1))))
            w2c = inverse_rigid_trans(c2w[:3,:4])
            pts_3d = np.dot(pts_3d_extend,np.transpose(w2c))
            pts_3d_extend = np.hstack((pts_3d, np.ones((8, 1))))
            if min(pts_3d_extend[:,2]) < 1e-6: 
                continue
            pts_2d = np.dot(pts_3d, np.transpose(np.array(
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                infos[i]['camera_intrinsic'][0]
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]

            img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
            cv2.putText(img, 'ID:{:03d}'.format(uid), (int(pts_2d[0, 0]),int(pts_2d[0, 1])), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(255,255,255), thickness=2)
        
        for lane,lid in lanes_all[i]:
            pts_2d = np.dot(lane, np.transpose(np.array(
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                infos[i]['camera_intrinsic']
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]
            cv2.polylines(img,[pts_2d[:,:2].astype(np.int32)],isClosed=0,color=(0,255,0),thickness=2)
        
        cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)

def bev_v(data_dir,obj_label_dir,line_label_dir,save_dir): 
    # obj det and lane det
    json_file = glob.glob(os.path.join(data_dir, '*.json'))
    infos = load_json_file(json_file[0])
    
    with open(line_label_dir,'r') as f:
        lane_labels = json.load(f) 
    # check parameter files and lane files
    assert len(infos) == len(lane_labels),'Length of param files do not match lane detection files...'
    for i in range(len(infos)): 
        assert (lane_labels[i]['file_path'].split('/'))[-1] == infos[i]['filename']\
        , 'Name of param files do not match lane detection files with {} and {}...'.format((lane_labels[i]['file_path'].split('/'))[-1],infos[i]['filename'])
    print('Lane detection files check completed...')

    obj_labels = sorted(glob.glob(os.path.join(obj_label_dir, '*.txt')))
    boxes_all = []
    n = len(obj_labels)
    n = 50
    for i in range(n):
        objects = read_label(obj_labels[i])
        #objects = []
        objects.append(Object3d_ego([i,1.6,1.6,4,-np.pi/2]))
        boxes = []
        c2v = np.array(infos[i]['c2v'])
        c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = compute_o2w_from_c2w(obj, c2v)
            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            if obj.type == "Ego":
                y_corners = [0, 0, 0, 0
                            , 0, 0, 0
                            , -h, -h, -h, -h]
            else:
                y_corners = [0, 0, 0, 0
                            , 0, 0, -h/2
                            , -h, -h, -h, -h]
            z_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:6,:2],obj.type,0))
        boxes_all.append(boxes)
    
    xmin = np.min([np.min([box[:,0].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    xmax = np.max([np.max([box[:,0].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    ymin = np.min([np.min([box[:,1].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    ymax = np.max([np.max([box[:,1].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    xmin = min(xmin,np.min([np.min([np.min([xyz[1] for xyz in lane_line['xyz']]) for lane_line in lane_label['lane_lines']]) for lane_label in lane_labels]))
    xmax = max(xmax,np.max([np.max([np.max([xyz[1] for xyz in lane_line['xyz']]) for lane_line in lane_label['lane_lines']]) for lane_label in lane_labels]))
    ymin = min(ymin,np.min([np.min([np.min([-xyz[0] for xyz in lane_line['xyz']]) for lane_line in lane_label['lane_lines']]) for lane_label in lane_labels]))
    ymax = max(ymax,np.max([np.max([np.max([-xyz[0] for xyz in lane_line['xyz']]) for lane_line in lane_label['lane_lines']]) for lane_label in lane_labels]))
    print(xmin,xmax,ymin,ymax)

    bev_dir = os.path.join(save_dir,'BEV_all_v')
    if not os.path.exists(bev_dir):
        os.mkdir(bev_dir)
    for (idx,boxes) in enumerate(tqdm(boxes_all)):
        fig = plotBEV(idx,boxes,(xmin,xmax,ymin,ymax),lane_labels[idx]['lane_lines'])
        save_file = os.path.join(bev_dir,'{:05d}.png'.format(idx))
        fig.savefig(save_file)
        plt.close()


def bev_w(data_dir,obj_label_dir,line_label_dir,save_dir): 
    # obj trc and lane det
    json_file = glob.glob(os.path.join(data_dir, '*.json'))
    infos = load_json_file(json_file[0])

    with open(line_label_dir,'r') as f:
        lane_labels = json.load(f) 
    # check parameter files and lane files
    assert len(infos) == len(lane_labels),'Length of param files do not match lane detection files...'
    for i in range(len(infos)): 
        assert (lane_labels[i]['file_path'].split('/'))[-1] == infos[i]['filename']\
        , 'Name of param files do not match lane detection files with {} and {}...'.format((lane_labels[i]['file_path'].split('/'))[-1],infos[i]['filename'])
    print('Lane detection files check completed...')
    
    boxes_all = []
    lanes_all = []
    n = len(infos)
    for i in range(n):
        lines = [line.rstrip() for line in open('./output_post.txt')]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(i)]
        
        boxes = []
        #v2w = np.array(infos[i]['v2w'])
        #v2w = np.concatenate((v2w,np.array([[0,0,0,1]])),axis=0)
        c2v = np.array(infos[i]['c2v'])
        c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
        v2w = np.array(infos[i]['v2w'])
        v2w = np.concatenate((v2w,np.array([[0,0,0,1]])),axis=0)
        c2w = v2w @ c2v
        
        lanes = []
        for lane in lane_labels[i]['lane_lines']: 
            temp = np.array(lane['xyz'])
            #temp[:,0],temp[:,1] = temp[:,1],-temp[:,0]
            temp = np.concatenate((temp,np.ones((temp.shape[0],1))),axis=1)
            c2v = np.array([[9.99991775e-01, -4.02539017e-03, 4.96265061e-04, 0.00000000e+00],
         [-4.45399714e-04, 1.26271973e-02, 9.99920175e-01, 0.00000000e+00],
         [-4.03133528e-03, -9.99912171e-01, 1.26253005e-02, 2.11585277e+00]])
            c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2c = inverse_rigid_trans(c2v)
            v2c[3,3] = 1
            temp = temp @ np.transpose(v2c) 
            ####
            # temp[:,0] = temp[:,0]/temp[:,1]*infos[i]['c2v'][2][3]
            # temp[:,2] = temp[:,2]/temp[:,1]*infos[i]['c2v'][2][3]
            # temp[:,1] = infos[i]['c2v'][2][3]     
            temp = temp @ np.transpose(c2w)
            lanes.append((temp,lane['lane_id'])) 

        for obj in objects: 
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:,:3],obj.type,obj.uid)) 
        lanes_all.append(lanes) 
        boxes_all.append(boxes)
    
    xmin,ymin = np.inf,np.inf 
    xmax,ymax = -np.inf,-np.inf 
    #xmin = np.min([np.min([box[:,0].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #xmax = np.max([np.max([box[:,0].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymin = np.min([np.min([box[:,1].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    #ymax = np.max([np.max([box[:,1].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    for boxes in boxes_all: 
        for box,btype,uid in boxes:
            xmin = min(xmin,box[:,0].min())
            xmax = max(xmax,box[:,0].max())
            ymin = min(ymin,box[:,1].min())
            ymax = max(ymax,box[:,1].max())
    #xmin = min(xmin,np.min([np.min([lane[:,0].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #xmax = max(xmax,np.max([np.max([lane[:,0].max() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymin = min(ymin,np.min([np.min([lane[:,1].min() for lane,lid in lanes]) for lanes in lanes_all]))
    #ymax = max(ymax,np.max([np.max([lane[:,1].max() for lane,lid in lanes]) for lanes in lanes_all]))
    for lanes in lanes_all: 
        for lane,lid in lanes: 
            xmin = min(xmin,lane[:,0].min())
            xmax = max(xmax,lane[:,0].max())
            ymin = min(ymin,lane[:,1].min())
            ymax = max(ymax,lane[:,1].max())
    #xmax = 2000

    bev_dir = os.path.join(save_dir,'BEV_all_w')
    if not os.path.exists(bev_dir):
        os.mkdir(bev_dir)
    for (idx,boxes) in enumerate(tqdm(boxes_all)):
        fig = plotBEV(idx,boxes,(xmin,xmax,ymin,ymax),lanes_all[idx])
        save_file = os.path.join(bev_dir,'{:05d}.png'.format(idx))
        fig.savefig(save_file)
        plt.close()

if __name__=="__main__": 
    show_2d_box('/root/Codes/tracking/EagerMOT/data/nuscenes/figure/straight'
                ,'/root/Codes/tracking/yolov10-main/figures/0927_straight'
                #'/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj/image'
                ,'/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj_straight/label_dt'
                ,'/root/Codes/tracking/EagerMOT/figures/0904_ens/straight')

    # bev_w('/root/Codes/tracking/EagerMOT/data/nuscenes/figure/curved'
    #     ,'/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj_curved/label_dt'
    #     ,'/root/Codes/tracking/EagerMOT/data/nuscenes/lane_detectors/nuscene_openlane_curved.json'
    #     ,'/root/Codes/tracking/EagerMOT/figures/0904_ens/curved')

    # fov_w('/root/Codes/tracking/EagerMOT/data/nuscenes/figure/straight'
    #     ,'/root/Codes/tracking/EagerMOT/data/nuscenes/figure/straight'
    #     ,'/root/Codes/tracking/EagerMOT/data/nuscenes/lane_detectors/nuscene_openlane_straight.json'
    #     ,'/root/Codes/tracking/EagerMOT/figures/0904_ens/straight')
    