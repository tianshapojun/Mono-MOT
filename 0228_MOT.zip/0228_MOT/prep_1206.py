import os
import shutil
import glob
import numpy as np
from shapely.geometry import Polygon
import json 
import pandas as pd

from utils.imu_utils import convertOxtsToPose

def inverse_rigid_trans(Tr):
    """ Inverse a rigid body transform matrix (3x4 as [R|t])
        [R'|-R't; 0|1]
    """
    inv_Tr = np.zeros_like(Tr)  # 3x4
    inv_Tr[0:3, 0:3] = np.transpose(Tr[0:3, 0:3])
    inv_Tr[0:3, 3] = np.dot(-np.transpose(Tr[0:3, 0:3]), Tr[0:3, 3])
    #inv_Tr = np.concatenate((inv_Tr,np.array([[0,0,0,1]])), axis = 0)
    inv_Tr[3,3] = 1
    return inv_Tr

def trans_xyw_rot(x,y,yaw):
    return np.array([[np.cos(yaw),-np.sin(yaw),0,x]
        ,[np.sin(yaw),np.cos(yaw),0,y]
        ,[0,0,1,0]
        ,[0,0,0,1]])

def box_iou(box1, box2):
    '''
    box1: array([1,10])
    box2: array([n,10])
    return: array(N)
    '''

    area1 = box1[:,10]# 1
    area2 = box2[:,10]# N

    inter = np.zeros(box2.shape[0])
    p1 = Polygon(box1[0,:8].reshape(4,2))
    for i in range(box2.shape[0]): 
        p2 = Polygon(box2[i,:8].reshape(4,2))
        intersection = p1.intersection(p2)
        y_inter = max(0,min(box1[0,9],box2[i,9])-max(box1[0,8],box2[i,8]))
        inter[i] = intersection.area * y_inter
    return np.clip(inter / (area1 + area2 - inter),0,1)


def nms(file_path, det_threshold = 0.4,iou_threshold = 0.3):
    lines = [line.rstrip() for line in open(file_path)]
    boxes = np.zeros((0,11))
    scores = []
    lines_no_empty = []
    for line in lines:
        if line == '':
            continue 
        data = line.split(" ")
        data[1:] = [float(x) for x in data[1:]]
        h,w,l = data[8], data[9], data[10]
        x,y,z = data[11], data[12], data[13]
        yaw = data[14]
        score = data[15]
        if score < det_threshold:
            continue
        box = np.array([[x+(l/2)*np.cos(-yaw)-(w/2)*np.sin(-yaw), z+(l/2)*np.sin(-yaw)+(w/2)*np.cos(-yaw)
                ,x+(l/2)*np.cos(-yaw)-(-w/2)*np.sin(-yaw), z+(l/2)*np.sin(-yaw)+(-w/2)*np.cos(-yaw)
                ,x+(-l/2)*np.cos(-yaw)-(-w/2)*np.sin(-yaw), z+(-l/2)*np.sin(-yaw)+(-w/2)*np.cos(-yaw)
                ,x+(-l/2)*np.cos(-yaw)-(w/2)*np.sin(-yaw), z+(-l/2)*np.sin(-yaw)+(w/2)*np.cos(-yaw)
                ,y-h,y
                ,w*l*h]])
        # if z > 40: 
        #     continue
        lines_no_empty.append(line)
        boxes = np.concatenate((boxes, box), axis = 0)
        scores.append(score)
    scores = np.array(scores)

    keep = []  # 最终保存的结果, 在boxes中对应的索引
    idxs = scores.argsort()  # 得分值从小到大的索引

    while True:  # 循环直到null
        if idxs.shape[0] == 0:  # 空
            break
        elif idxs.shape[0] == 1:  # 一个框
            keep.append(idxs[0])
            break
        # 得分最大框对应的索引
        max_score_index = idxs[-1]
        # 得分最大框坐标信息
        max_score_box = boxes[max_score_index][None, :]  # [1, 11]
        keep.append(max_score_index)  # 保留该结果
        idxs = idxs[:-1]  # 将得分最大的框从索引中删除
        other_boxes = boxes[idxs]  # [?, 11],其余框
        ious = box_iou(max_score_box, other_boxes)  # 计算得分最大的框与其他框的IoU [1, ?]
        #print(ious)
        idxs = idxs[ious <= iou_threshold]  # 去掉与得分最高的框的重合度较高的框
    
    final = [line for idx,line in enumerate(lines_no_empty) if idx in keep ]
    if len(final) != len(lines_no_empty):
        print(file_path)
    return final

def load_json_file(file_path):
    json_lines = []
    with open(file_path, 'r') as file:
        for line in file:
            # print("line", line)
            try:
                # 尝试逐行解析 JSON 对象
                lane_data = json.loads(line.strip())
                json_lines.append(lane_data)
            except json.JSONDecodeError:
                # 跳过格式错误的行
                continue
    return json_lines

def prep_process(label_3d_dir,n=29,pose='c2w'): 
    
    root_dir = os.path.dirname(os.path.abspath(__file__))
    folder_dir = os.path.join(root_dir,'monodetr')

    if os.path.exists(folder_dir):
        shutil.rmtree(folder_dir)
    os.mkdir(folder_dir)

    # 原始数据
    data_dir = os.path.join(folder_dir,'data')
    if not os.path.exists(data_dir):
        os.mkdir(data_dir)
    data_dir = os.path.join(folder_dir,'data','test')
    if not os.path.exists(data_dir):
        os.mkdir(data_dir)

    # calib
    calib_dir = os.path.join(folder_dir,'data','test','calib')
    if not os.path.exists(calib_dir):
        os.mkdir(calib_dir)
    calib_dst = os.path.join(folder_dir,'data','test','calib','0000.txt')
    calib_src = os.path.join(root_dir,'sample','data','test','calib','0000.txt')
    shutil.copy2(calib_src,calib_dst)
    # samples = np.array([2000,0,500,0,0,2000,200,0,0,0,1,0])
    # lines_old = []
    # with open(calib_src, "r") as f:
    #     for line in f.readlines():
    #         line = line.rstrip()
    #         lines_old.append(line)
    # with open(calib_dst, "w") as f:
    #     for line in lines_old: 
    #         if line[:2] != 'P2': 
    #             f.write(line)
    #             f.write('\n')
    #         else: 
    #             f.write('P2:')
    #             for sample in samples: 
    #                 f.write(' ' + str(sample))
    #             f.write('\n')

    # image
    img_dir = os.path.join(folder_dir,'data','test','image_02')
    if not os.path.exists(img_dir):
        os.mkdir(img_dir)
    img_dir = os.path.join(folder_dir,'data','test','image_02','0000')
    if not os.path.exists(img_dir):
        os.mkdir(img_dir)
    image = '/root/Codes/tracking/EagerMOT/sample/data/test/image_02/0000/000000.png'
    for idx in range(n): 
        shutil.copy2(image,os.path.join(img_dir,'{:06d}.png'.format(idx)))

    # ego_motion
    pose_dir = os.path.join(folder_dir,'data','test','ego_motion')
    if not os.path.exists(pose_dir):
        os.mkdir(pose_dir)
    ego_tf = np.zeros((n,4,4))
    with open(label_3d_dir,'r') as f:
        label = json.load(f)
    w2c_0 = np.array([[np.sin(label['ego'][0][2]),-np.cos(label['ego'][0][2]),0
        ,-np.sin(label['ego'][0][2])*label['ego'][0][0]+np.cos(label['ego'][0][2])*label['ego'][0][1]]
        ,[0,0,0,2]
        ,[np.cos(label['ego'][0][2]),np.sin(label['ego'][0][2]),0
        ,-np.cos(label['ego'][0][2])*label['ego'][0][0]-np.sin(label['ego'][0][2])*label['ego'][0][1]]
        ,[0,0,0,1]])
    for idx in range(n): 
        #ego_tf[idx] = np.eye(4)
        c2w_i = np.array([[np.sin(label['ego'][idx][2]),0,np.cos(label['ego'][idx][2]),label['ego'][idx][0]]
        ,[-np.cos(label['ego'][idx][2]),0,np.sin(label['ego'][idx][2]),label['ego'][idx][1]]
        ,[0,0,0,0],[0,0,0,1]])
        ego_tf[idx] = np.dot(w2c_0,c2w_i)
    np.save(os.path.join(pose_dir,'0000.npy'),ego_tf)

    # 2d_seg
    seg2d_dir = os.path.join(folder_dir,'2dseg')
    if not os.path.exists(seg2d_dir):
        os.mkdir(seg2d_dir)
    f = open(os.path.join(seg2d_dir, "0000.txt"), "w")
    f.close()
    #shutil.copy2(os.path.join(label_2d_dir,'yolo_label.txt'),os.path.join(seg2d_dir, "0000.txt"))

    # 3dlabel
    det3d_dir = os.path.join(folder_dir,'3dlabel')
    if not os.path.exists(det3d_dir):
        os.mkdir(det3d_dir)
    det3d_dir = os.path.join(folder_dir,'3dlabel','0000')
    if not os.path.exists(det3d_dir):
        os.mkdir(det3d_dir)
    with open(label_3d_dir,'r') as f:
        label = json.load(f)
    for idx in range(n): 
        with open(os.path.join(det3d_dir,'{:06d}.txt'.format(idx)),'w') as f: 
            for line in label['obj'][idx]:                
                veh_x = np.array([np.sin(label['ego'][idx][2]),-np.cos(label['ego'][idx][2])])\
                 @ np.array([line[0]-label['ego'][idx][0],line[1]-label['ego'][idx][1]])  
                veh_y = np.array([np.cos(label['ego'][idx][2]),np.sin(label['ego'][idx][2])])\
                 @ np.array([line[0]-label['ego'][idx][0],line[1]-label['ego'][idx][1]])  
                veh_yaw = label['ego'][idx][2] - line[2] - np.pi/2
                veh_yaw = (veh_yaw + np.pi)%(2*np.pi) - np.pi        
                f.write('Car 0.0 0 {} 0 0 0 0 1.5 1.7 4.4 {} 0.0 {} {} 0.9\n'.format(veh_yaw,veh_x,veh_y,veh_yaw))
                #f.write('Car 0.0 0 {} 0 0 0 0 1.5 1.7 4.4 {} 2.0 {} {} 0.8\n'.format(line[2],line[0],line[1],line[2]))
    return 


if __name__=='__main__': 
    '''
    图像文件夹
    其中图片按时间顺序从小到大命名,例如'001.png','002.png','003.png'...
    
    标签文件夹
    其中标签文件按图像命名规则一一对应,例如'001.txt','002.txt','003.txt'... 
    标签文件按照kitti格式,共16个值,
    第1个值:代表类别,可以为['Car', 'Van', 'Truck','Pedestrian', 'Person_sitting', 'Cyclist','Tram', 'Misc' , 'DontCare'],
    第2个值:代表物体是否被截断,固定为-1,
    第3个值:代表物体是否被遮挡,固定为-1,
    第4个值:代表物体的观察角度,固定为0,
    第5-8个值:代表物体的2D bounding box,分别为xmin、ymin、xmax、ymax,
    第9-11个值:代表物体的高宽长(hwl)(单位：米),
    第12-14个值:代表3D bounding box的中心坐标(相机坐标系下),
    第15个值:代表物体的航向角,
    第16个值:代表置信度,

    外参文件夹
    其中外参文件按图像命名规则一一对应,例如'001.txt','002.txt','003.txt'... 
    外参文件为1行16列,即4x4矩阵变形,以空格间隔,表示相机坐标系和世界坐标系之间的转换,
    '''

    fig_dir = '/root/Codes/tracking/EagerMOT/sample/data/test/image_02/0000'
    label_dir = '/root/Codes/tracking/EagerMOT/sample/3dlabel/0000'
    #prep_process(fig_dir,label_dir,'')

    nms('/root/Codes/tracking/EagerMOT/100/dt_label/000345.txt')