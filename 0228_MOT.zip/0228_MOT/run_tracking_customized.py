import time
from itertools import product
from typing import List, Iterable, Mapping
import os
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib
import cv2
import glob

# for NuScenes eval
#from nuscenes.eval.common.config import config_factory
#from nuscenes.eval.tracking.evaluate import TrackingEval

import dataset_classes.kitti.mot_kitti as mot_kitti
#from dataset_classes.nuscenes.dataset import MOTDatasetNuScenes
from utils import io
from configs.params import TRAIN_SEQ, VAL_SEQ, TRACK_VAL_SEQ, build_params_dict, KITTI_BEST_PARAMS, NUSCENES_BEST_PARAMS, variant_name_from_params
from configs.local_variables import NUSCENES_WORK_DIR, MOUNT_PATH
import inputs.utils as input_utils
from prep import prep_process,trans_xyw_rot,load_json_file
from utils.camera_utils import Calibration,inverse_rigid_trans,read_images_file
from utils.gt_utils import compute_box_3d,read_label,draw_gt_boxes3d,compute_o2w,compute_o2w_from_c2w
from utils.imu_utils import convertOxtsToPose
from post_0210 import post_process

KITTI_WORK_DIR = MOUNT_PATH + "/monodetr/data"
SPLIT = 'test'

def perform_tracking_full(dataset, params, target_sequences=[], sequences_to_exclude=[], print_debug_info=True):

    if len(target_sequences) == 0:
        target_sequences = dataset.sequence_names(SPLIT)

    total_frame_count = 0
    total_time = 0
    total_time_tracking = 0
    total_time_fusion = 0
    total_time_reporting = 0

    for sequence_name in target_sequences:
        if len(sequences_to_exclude) > 0:
            if sequence_name in sequences_to_exclude:
                print(f'Skipped sequence {sequence_name}')
                continue

        print(f'Starting sequence: {sequence_name}')
        start_time = time.time()
        sequence = dataset.get_sequence(SPLIT, sequence_name)
        sequence.mot.set_track_manager_params(params)
        variant = variant_name_from_params(params)
        run_info = sequence.perform_tracking_for_eval(params)
        if "total_time_mot" not in run_info:
            continue

        total_time = time.time() - start_time
        if print_debug_info:
            print(f'Sequence {sequence_name} took {total_time:.2f} sec, {total_time / 60.0 :.2f} min')
            print(
                f'Matching took {run_info["total_time_matching"]:.2f} sec, {100 * run_info["total_time_matching"] / total_time:.2f}%')
            print(
                f'Creating took {run_info["total_time_creating"]:.2f} sec, {100 * run_info["total_time_creating"] / total_time:.2f}%')
            print(
                f'Fusion   took {run_info["total_time_fusion"]:.2f} sec, {100 * run_info["total_time_fusion"] / total_time:.2f}%')
            print(
                f'Tracking took {run_info["total_time_mot"]:.2f} sec, {100 * run_info["total_time_mot"] / total_time:.2f}%')

            print(
                f'{run_info["matched_tracks_first_total"]} 1st stage and {run_info["matched_tracks_second_total"]} 2nd stage matches')

        total_time += total_time
        total_time_fusion += run_info["total_time_fusion"]
        total_time_tracking += run_info["total_time_mot"]
        total_time_reporting += run_info["total_time_reporting"]
        total_frame_count += len(sequence.frame_names)

    if total_frame_count == 0:
        return variant, run_info

    dataset.save_all_mot_results(run_info["mot_3d_file"])

    if not print_debug_info:
        return variant, run_info

    # Overall variant stats
    # Timing
    print("\n")
    print(
        f'Fusion    {total_time_fusion: .2f} sec, {(100 * total_time_fusion / total_time):.2f}%')
    print(f'Tracking  {total_time_tracking: .2f} sec, {(100 * total_time_tracking / total_time):.2f}%')
    print(f'Reporting {total_time_reporting: .2f} sec, {(100 * total_time_reporting / total_time):.2f}%')
    print(
        f'Tracking-fusion framerate: {total_frame_count / (total_time_fusion + total_time_tracking):.2f} fps')
    print(f'Tracking-only framerate: {total_frame_count / total_time_tracking:.2f} fps')
    print(f'Total framerate: {total_frame_count / total_time:.2f} fps')
    print()

    # Fused instances stats
    total_instances = run_info['instances_both'] + run_info['instances_3d'] + run_info['instances_2d']
    if total_instances > 0:
        print(f"Total instances 3D and 2D: {run_info['instances_both']} " +
              f"-> {100.0 * run_info['instances_both'] / total_instances:.2f}%")
        print(f"Total instances 3D only  : {run_info['instances_3d']} " +
              f"-> {100.0 * run_info['instances_3d'] / total_instances:.2f}%")
        print(f"Total instances 2D only  : {run_info['instances_2d']} " +
              f"-> {100.0 * run_info['instances_2d'] / total_instances:.2f}%")
        print()

    # Matching stats
    print(f"matched_tracks_first_total {run_info['matched_tracks_first_total']}")
    print(f"unmatched_tracks_first_total {run_info['unmatched_tracks_first_total']}")

    print(f"matched_tracks_second_total {run_info['matched_tracks_second_total']}")
    print(f"unmatched_tracks_second_total {run_info['unmatched_tracks_second_total']}")
    print(f"unmatched_dets2d_second_total {run_info['unmatched_dets2d_second_total']}")

    first_matched_percentage = (run_info['matched_tracks_first_total'] /
                                (run_info['matched_tracks_first_total'] + run_info['unmatched_tracks_first_total']))
    print(f"percentage of all tracks matched in 1st stage {100.0 * first_matched_percentage:.2f}%")

    second_matched_percentage = (
        run_info['matched_tracks_second_total'] / run_info['unmatched_tracks_first_total'])
    print(f"percentage of leftover tracks matched in 2nd stage {100.0 * second_matched_percentage:.2f}%")

    second_matched_dets2d_second_percentage = (run_info['matched_tracks_second_total'] / (
        run_info['unmatched_dets2d_second_total'] + run_info['matched_tracks_second_total'] + 1e-6))
    print(f"percentage dets 2D matched in 2nd stage {100.0 * second_matched_dets2d_second_percentage:.2f}%")

    final_unmatched_percentage = (run_info['unmatched_tracks_second_total'] / (
        run_info['matched_tracks_first_total'] + run_info['unmatched_tracks_first_total']))
    print(f"percentage tracks unmatched after both stages {100.0 * final_unmatched_percentage:.2f}%")

    print(f"\n3D MOT saved in {run_info['mot_3d_file']}", end="\n\n")
    return variant, run_info


def perform_tracking_with_params(dataset, params,
                                 target_sequences: Iterable[str] = [],
                                 sequences_to_exclude: Iterable[str] = []):
    start_time = time.time()
    variant, run_info = perform_tracking_full(dataset, params,
                                              target_sequences=target_sequences,
                                              sequences_to_exclude=sequences_to_exclude)
    print(f'Variant {variant} took {(time.time() - start_time) / 60.0:.2f} mins')
    return run_info


def run_on_nuscenes():
    VERSION = "v1.0-trainval"
    mot_dataset = MOTDatasetNuScenes(work_dir=NUSCENES_WORK_DIR,
                                     det_source=input_utils.CENTER_POINT,
                                     seg_source=input_utils.MMDETECTION_CASCADE_NUIMAGES,
                                     version=VERSION)

    # if want to run on specific sequences only, add their str names here
    target_sequences: List[str] = []

    # if want to exclude specific sequences, add their str names here
    sequences_to_exclude: List[str] = []

    run_info = perform_tracking_with_params(
        mot_dataset, NUSCENES_BEST_PARAMS, target_sequences, sequences_to_exclude)
    mot_dataset.reset()


def run_on_kitti():
    # To reproduce our test set results run this on the TEST set

    # To reproduce "Ours" results in Table II in the paper run this on the VAL set

    # To reproduce "Ours (dagger)" results in Table II in the paper,
    # change det_source to input_utils.AB3DMOT and run on the VAL set
    mot_dataset = mot_kitti.MOTDatasetKITTI(work_dir=KITTI_WORK_DIR,
                                            det_source=input_utils.POINTGNN_T3,
                                            seg_source=input_utils.TRACKING_BEST)
    
    # if want to run on specific sequences only, add their str names here
    target_sequences: List[str] = []

    # if want to exclude specific sequences, add their str names here
    sequences_to_exclude: List[str] = []

    perform_tracking_with_params(mot_dataset, KITTI_BEST_PARAMS, target_sequences, sequences_to_exclude)

class Object3d_ego(object):
    """ 3d object label """

    def __init__(self, data):
        self.type = 'Ego'  # 'Car', 'Pedestrian', ...
        self.frame = data[0]  
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.ry = data[4]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.t = (0,0,0)
        self.confidence = -1
        self.uid = -1

class Object3d_simple(object):
    """ 3d object label """

    def __init__(self, label_file_line):
        data = label_file_line.split(" ")
        data = data[3:] + [data[2]]
        data[1:] = [float(x) for x in data[1:]]  
        self.type = data[0]
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.t = (data[4], data[5], data[6])  # location (x,y,z) in camera coord.
        self.ry = data[7]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.uid = int(data[-1])

def plotBEV(file,boxes,border):
    fig = plt.figure(dpi=500,figsize=(5,2))
    axes = plt.gca()
    #fig, axes = plt.subplots(dpi=500)
    axes.set_title('Frame:{}'.format(file))
    axes.set_aspect('equal', adjustable='box')
    axes.set_xlim([border[0]-5, border[1]+5])
    #axes.set_xlim([-2800, -2600])
    axes.set_ylim([border[2]-5, border[3]+5])
    for box,btype,uid in boxes: 
        if btype == 'Ego': 
            clr = 'red'
        elif btype in ["Car","Van"]: 
            clr = 'blue'
        else: 
            clr = 'green'
        rect = matplotlib.patches.Polygon(box[:4,:2], closed=True,zorder=1,fill=False,color=clr)
        axes.add_patch(rect)
        axes.plot(box[4:6,0],box[4:6,1],color='black',linewidth=.5)
        axes.text(np.mean(box[:4,0]),np.mean(box[:4,1])-0.5,str(int(uid)),horizontalalignment='center', fontsize=2.5,fontweight='semibold')
    return fig

def postprocessPoses(poses_in):

    R = np.array([[0,1,0,0], [-1,0,0,0], [0,0,1,0], [0,0,0,1]])
    
    poses  = []
    
    for i in range(len(poses_in)):
        P = poses_in[i]
        poses.append( np.matmul(R, P) )
    
    return poses

def f2ts(n,freq = 10): 
    # 毫米级时间戳，返回整数
    return int(1000/freq*n)

#def show_image_with_boxes(n,calib_dir, oxts_dir, label_det_dir, label_mot_dir, fig_dir, save_dir, out_dir, showBEV = True, show2d = False):
def show_image_with_boxes(n,c2w_dir, label_det_dir, label_mot3d_dir, label_mot2d_dir,fig_dir, save_dir, out_dir, pose='c2w' ,showBEV = True, show2d = False):

    """ Show image with 2D bounding boxes """
    #calib = Calibration(calib_dir)
    
    #oxts = np.loadtxt(oxts_dir)
    #poses = convertOxtsToPose(oxts)
    #poses = postprocessPoses(poses)

    c2w = np.zeros((n,4,4))
    if pose == 'c2w':
        c2ws = sorted(glob.glob(os.path.join(c2w_dir, '*.txt')))
        for i in range(n):
            with open(c2ws[i],'r') as f: 
                for line in f.readlines(): 
                    c2w[i] = np.array([float(x) for x in line.split()]).reshape(4,4)
    elif pose == 'oxts': 
        oxts = np.loadtxt(os.path.join(c2w_dir,'pose.txt'))
        poses = convertOxtsToPose(oxts)
        with open(os.path.join(c2w_dir,'c2v.txt'),'r') as f: 
            for line in f.readlines(): 
                c2v = np.array([float(x) for x in line.split()]).reshape(4,4)
        for i in range(n): 
            c2w[i] = poses[i] @ c2v
    elif pose == 'xyyaw': 
        locations = np.loadtxt(os.path.join(c2w_dir,'xyyaw.txt'))
        with open(os.path.join(c2w_dir,'c2v.txt'),'r') as f: 
            for line in f.readlines(): 
                c2v = np.array([float(x) for x in line.split()]).reshape(4,4)
        for i in range(n): 
            x,y,yaw = locations[i,0],locations[i,1],locations[i,2]
            c2w[i] = trans_xyw_rot(x,y,yaw) @ c2v
    elif pose == '0905':
        infos = load_json_file(c2w_dir)
        for i in range(n):
            c2v = np.array(infos[i]['c2v'])
            c2v = np.concatenate((c2v,np.array([[0,0,0,1]])),axis=0)
            v2w = np.array(infos[i]['v2w'])
            #v2w = np.concatenate((v2w,np.array([[0,0,0,1]])),axis=0)
            c2w[i] = v2w @ c2v
    
    #c2w = postprocessPoses(c2w)

    out_file = os.path.join(out_dir,'output.txt')
    if os.path.exists(out_file):  
        os.remove(out_file)
    
    objs_dict = {}
    with open(out_file,'w') as f: 
        boxes_all = []
        for i in tqdm(range(n)): 
            objects = read_label(label_mot3d_dir, False, i, True)
            objects.append(Object3d_ego([i,1.6,1.6,4,-np.pi/2]))
            boxes = []
            for obj in objects:
                #if obj.type == "DontCare":
                if obj.type not in ["Ego","Car","Van","Cyclist"]:
                    continue
                #tf_matrix = compute_o2w(obj, calib,poses[i])
                tf_matrix = compute_o2w_from_c2w(obj, c2w[i])

                l = obj.l
                w = obj.w
                h = obj.h
                x_corners = [l / 2, l / 2, -l / 2, -l / 2
                            ,l / 2, l / 2 + 1.0, 0
                            ,l / 2, l / 2, -l / 2, -l / 2]
                if obj.type == "Ego":
                    y_corners = [0, 0, 0, 0
                                , 0, 0, 0
                                , -h, -h, -h, -h]
                else:
                    y_corners = [0, 0, 0, 0
                                , 0, 0, -h/2
                                , -h, -h, -h, -h]
                z_corners = [w / 2, -w / 2, -w / 2, w / 2
                            , 0, 0, 0                
                            , w / 2, -w / 2, -w / 2, w / 2]
                ones = [1,1,1,1,1,1,1,1,1,1,1]
                corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
                box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
                boxes.append((box3d_pts_3d_world[:6,:2],obj.type,obj.uid))
                #if obj.type != "Ego":
                f.write(str(obj.frame) + ' ')
                f.write(str(f2ts(i)) + ' ') # add timestamp
                f.write(str(obj.uid) + ' ')
                f.write(obj.type + ' ')
                f.write('{} {} {} '.format(obj.h,obj.w,obj.l))
                f.write('{} {} {} '.format(box3d_pts_3d_world[6,0],box3d_pts_3d_world[6,1],box3d_pts_3d_world[6,2]))
                f.write('{} '.format(np.arctan2(box3d_pts_3d_world[5,1]-box3d_pts_3d_world[4,1],box3d_pts_3d_world[5,0]-box3d_pts_3d_world[4,0])))
                #f.write(str(obj.confidence))
                f.write(str(abs(obj.t[0])))
                f.write('\n')
                try: 
                    objs_dict[obj.uid].append([obj.frame,f2ts(i),obj.uid,obj.type,obj.h,obj.w,obj.l
                        ,box3d_pts_3d_world[6,0],box3d_pts_3d_world[6,1],box3d_pts_3d_world[6,2]
                        ,np.arctan2(box3d_pts_3d_world[5,1]-box3d_pts_3d_world[4,1],box3d_pts_3d_world[5,0]-box3d_pts_3d_world[4,0])
                        #,obj.confidence])
                        ,abs(obj.t[0])])
                except: 
                    objs_dict[obj.uid] = [[obj.frame,f2ts(i),obj.uid,obj.type,obj.h,obj.w,obj.l
                        ,box3d_pts_3d_world[6,0],box3d_pts_3d_world[6,1],box3d_pts_3d_world[6,2]
                        ,np.arctan2(box3d_pts_3d_world[5,1]-box3d_pts_3d_world[4,1],box3d_pts_3d_world[5,0]-box3d_pts_3d_world[4,0])
                        #,obj.confidence]]
                        ,abs(obj.t[0])]]
            boxes_all.append(boxes)
        #print(boxes_all[0])
        #quit()
        print('Txt file completed...')
    
    out_file = os.path.join(out_dir,'output_post.txt')
    if os.path.exists(out_file):  
        os.remove(out_file)
    post_process(objs_dict, out_file)
    print('Post txt file completed...')
    #quit()

    boxes_all = []
    for i in tqdm(range(n)): 
        lines = [line.rstrip() for line in open(out_file)]
        objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(i)]

        #objects = read_label(out_file, False, i, True)
        #objects.append(Object3d_ego([i,1.6,1.6,4,-np.pi/2]))
        boxes = []
        for obj in objects:
            #if obj.type == "DontCare":
            if obj.type not in ["Ego","Car","Van","Cyclist"]:
                continue
            tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])

            l = obj.l
            w = obj.w
            h = obj.h
            x_corners = [l / 2, l / 2, -l / 2, -l / 2
                        ,l / 2, l / 2 + 1.0, 0
                        ,l / 2, l / 2, -l / 2, -l / 2]
            z_corners = [h/2, h/2, h/2, h/2
                            , 0, 0, -h/2
                            , -h/2, -h/2, -h/2, -h/2]
            y_corners = [w / 2, -w / 2, -w / 2, w / 2
                        , 0, 0, 0                
                        , w / 2, -w / 2, -w / 2, w / 2]
            ones = [1,1,1,1,1,1,1,1,1,1,1]
            corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
            box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
            boxes.append((box3d_pts_3d_world[:,:3],obj.type,obj.uid))               
        boxes_all.append(boxes)
    
    xmin = np.min([np.min([box[:,0].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    xmax = np.max([np.max([box[:,0].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    ymin = np.min([np.min([box[:,1].min() for box,btype,uid in boxes]) for boxes in boxes_all])
    ymax = np.max([np.max([box[:,1].max() for box,btype,uid in boxes]) for boxes in boxes_all])
    
    # show BEV with proprocess MOT results
    if showBEV:
        bev_dir = os.path.join(save_dir,'BEV')
        if not os.path.exists(bev_dir):
            os.mkdir(bev_dir)
        for (idx,boxes) in enumerate(tqdm(boxes_all)):
            fig = plotBEV(idx,boxes,(xmin,xmax,ymin,ymax))
            save_file = os.path.join(bev_dir,'{:05d}.png'.format(idx))
            fig.savefig(save_file)
            plt.close()
            #from PIL import Image
            #img = Image.open(save_file)
        print('2D BEV results completed...')

    # show 2d with mot2D results
    # if show2d: 
    #     fov_dir = os.path.join(save_dir,'FOV_new')
    #     if not os.path.exists(fov_dir):
    #         os.mkdir(fov_dir)
    #     images = glob.glob(os.path.join(fig_dir, '*.png'))
    #     images = sorted(images)
    #     for i in tqdm(range(n)): 
    #         objects = read_label(label_mot2d_dir, False, i, True)
    #         img = cv2.imread(images[i])
    #         for obj in objects: 
    #             if obj.type not in ["Car","Van","Cyclist"]:
    #                 continue
    #             cv2.rectangle(img, (int(obj.box2d[0]),int(obj.box2d[1])), (int(obj.box2d[2]),int(obj.box2d[3])), (0, 255, 0), 2)
    #             cv2.putText(img, 'ID:{:03d}'.format(obj.uid), (int(obj.box2d[0]),int(obj.box2d[1])), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(0,0,255), thickness=2)
    #         cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)
    #     print("2D detection results completed...")
    
    # show 2d with mot3D projecting results
    # if show2d: 
    #     fov_dir = os.path.join(save_dir,'FOV_mot')
    #     if not os.path.exists(fov_dir):
    #         os.mkdir(fov_dir)
    #     images = glob.glob(os.path.join(fig_dir, '*.jpg'))
    #     images = sorted(images)
    #     for i in tqdm(range(n)): 
    #         objects = read_label(label_mot3d_dir, False, i, True)
    #         img = cv2.imread(images[i])
    #         for obj in objects: 
    #             if obj.type not in ["Car","Van","Cyclist"]:
    #                 continue
    #             tf_matrix = np.array([[np.cos(obj.ry),0,np.sin(obj.ry),obj.t[0]]
    #                     ,[0,1,0,obj.t[1]]
    #                     ,[-np.sin(obj.ry),0,np.cos(obj.ry),obj.t[2]]])
    #             l = obj.l
    #             w = obj.w
    #             h = obj.h
    #             x_corners = [l / 2, l / 2, -l / 2, -l / 2
    #                         ,l / 2, l / 2, -l / 2, -l / 2]
    #             y_corners = [0, 0, 0, 0
    #                             , -h, -h, -h, -h]
    #             z_corners = [w / 2, -w / 2, -w / 2, w / 2            
    #                         , w / 2, -w / 2, -w / 2, w / 2]
    #             ones = [1,1,1,1,1,1,1,1]
    #             corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
    #             box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
    #             pts_3d_extend = np.hstack((box3d_pts_3d_world, np.ones((8, 1))))
    #             if min(pts_3d_extend[:,2]) < 1e-6: 
    #                 continue
    #             pts_2d = np.dot(pts_3d_extend, np.transpose(np.array(
    #                 #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
    #                 #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
    #                 [[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
    #             )))
    #             pts_2d[:, 0] /= pts_2d[:, 2]
    #             pts_2d[:, 1] /= pts_2d[:, 2]

    #             img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
    #             cv2.putText(img, 'ID:{:03d}'.format(obj.uid), (int(pts_2d[4, 0]),int(pts_2d[4, 1]-5)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(255,255,255), thickness=2)
    #         cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)
    #     print("2D detection results completed...")

    # show 2d with proprocess MOT projecting results
    if show2d: 
        fov_dir = os.path.join(save_dir,'FOV_mot')
        if not os.path.exists(fov_dir):
            os.mkdir(fov_dir)
        images = glob.glob(os.path.join(fig_dir, '*.jpg'))
        images = sorted(images)
        for i in tqdm(range(n)): 
            img = cv2.imread(images[i])
            for box,btype,uid in boxes_all[i]: 
                if btype not in ["Car","Van","Cyclist"]:
                    continue
                pts_3d_extend = np.hstack((box[[0,1,2,3,7,8,9,10],:], np.ones((8, 1))))
                w2c = inverse_rigid_trans(c2w[i][:3,:4])
                pts_3d = np.dot(pts_3d_extend,np.transpose(w2c))
                pts_3d_extend = np.hstack((pts_3d, np.ones((8, 1))))
                if min(pts_3d_extend[:,2]) < 1e-6: 
                    continue
                pts_2d = np.dot(pts_3d, np.transpose(np.array(
                    #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,4.485728000000e+01],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,2.163791000000e-01],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,2.745884000000e-03]]  
                    #[[7.215377000000e+02,0.000000000000e+00,6.095593000000e+02,0],[0.000000000000e+00,7.215377000000e+02,1.728540000000e+02,0],[0.000000000000e+00,0.000000000000e+00,1.000000000000e+00,0]]                  
                    #[[1252.8131021185304, 0.0, 826.588114781398,0], [0.0, 1252.8131021185304, 469.9846626224581,0], [0.0, 0.0, 1.0,0]]
                    infos[i]['camera_intrinsic'][0]
                )))
                pts_2d[:, 0] /= pts_2d[:, 2]
                pts_2d[:, 1] /= pts_2d[:, 2]

                # print(pts_3d)
                # print(infos[i]['camera_intrinsic'])
                # print(pts_2d)
                # quit()

                img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
                cv2.putText(img, 'ID:{:03d}'.format(uid), (int(pts_2d[0, 0]),int(pts_2d[0, 1])), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.5, color=(255,255,255), thickness=2)
            cv2.imwrite(os.path.join(fov_dir,'{:05d}.png'.format(i)),img)
    print("2D detection results completed...")

def draw_projected_box3d(image, qs, color=(0, 255, 0), thickness=1):
    """ Draw 3d bounding box in image
        qs: (8,3) array of vertices for the 3d box in following order:
            1 -------- 0
           /|         /|
          2 -------- 3 .
          | |        | |
          . 5 -------- 4
          |/         |/
          6 -------- 7
    """
    qs = qs.astype(np.int32)
    for k in range(0, 4):
        # Ref: http://docs.enthought.com/mayavi/mayavi/auto/mlab_helper_functions.html
        i, j = k, (k + 1) % 4
        # use LINE_AA for opencv3
        # cv2.line(image, (qs[i,0],qs[i,1]), (qs[j,0],qs[j,1]), color, thickness, cv2.CV_AA)
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
        i, j = k + 4, (k + 1) % 4 + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)

        i, j = k, k + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
    return image

if __name__ == "__main__":
    '''
    输入为图像文件夹路径,标签文件夹路径,外参文件夹路径
    图像文件夹
    其中图片按时间顺序从小到大命名,例如'001.png','002.png','003.png'...
    
    标签文件夹
    其中标签文件按图像命名规则一一对应,例如'001.txt','002.txt','003.txt'... 
    标签文件按照kitti格式,共16个值,
    第1个值:代表类别,可以为['Car', 'Van', 'Truck','Pedestrian', 'Person_sitting', 'Cyclist','Tram', 'Misc' , 'DontCare'],
    第2个值:代表物体是否被截断,固定为-1,
    第3个值:代表物体是否被遮挡,固定为-1,
    第4个值:代表物体的观察角度,固定为0,
    第5-8个值:代表物体的2D bounding box,分别为xmin、ymin、xmax、ymax,
    第9-11个值:代表物体的高宽长(hwl)(单位：米),
    第12-14个值:代表3D bounding box的中心坐标(相机坐标系下),
    第15个值:代表物体的航向角,
    第16个值:代表置信度,

    外参文件夹支持3种格式,
    1.提供C2W信息,其中外参文件按图像命名规则一一对应,例如'001.txt','002.txt','003.txt'... 
    C2W为1行16列,即4x4矩阵变形,以空格间隔,表示相机坐标系和世界坐标系之间的转换,

    2.提供pose信息,'pose.txt';C2V信息,'c2v.txt'
    pose为n行6列,其中n与图片数量一致,每一行的数值分别代表
    lat:   latitude of the oxts-unit (deg)  #维度
    lon:   longitude of the oxts-unit (deg) # 经度
    alt:   altitude of the oxts-unit (m) # 高度
    roll:  roll angle (rad),    0 = level, positive = left side up,      range: -pi   .. +pi  # 倾斜角，左倾为正，
    pitch: pitch angle (rad),   0 = level, positive = front down,        range: -pi/2 .. +pi/2 # 俯仰角，正面朝下为正
    yaw:   heading (rad),       0 = east,  positive = counter clockwise, range: -pi   .. +pi # 航向，逆时针为正
    C2V为1行16列,即4x4矩阵变形,以空格间隔,表示相机坐标系和车辆(GPS)坐标系之间的转换,

    3.提供x/y/yaw信息,'xyyaw.txt';C2V信息,'c2v.txt'
    pose为n行3列,其中n与图片数量一致,每一行的数值分别代表
    x:世界坐标系下
    y:世界坐标系下
    yaw:航向角
    C2V为1行16列,即4x4矩阵变形,以空格间隔,表示相机坐标系和车辆(GPS)坐标系之间的转换,

    输出文件为.txt形式,每一行(12个值,以空格间隔)记录某一帧某一物体信息,具体字段如下:
    第1个值:代表帧数,
    第2个值:时间戳,13位毫秒级
    第3个值:代表物体uid(主车为-1),
    第4个值:代表类别,可以为['Car','Pedestrian','Ego'],
    第5-7个值:代表物体的高宽长(hwl)(单位：米),
    第8-10个值:代表3D bounding box的中心坐标(主车为相机坐标,在世界坐标系下),
    第11个值:代表物体的航向角(-pi,pi],
    第12个值:代表置信度(主车为-1),
    第13-14个值:vx和vy,
    '''
    fig_dir = '/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj_straight/image'
    label_3d_dir = '/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj_straight/label_dt'
    label_2d_dir = '/root/Codes/tracking/EagerMOT/data/nuscenes/object_detectors/nu_proj_straight'
    ex_dir = '/root/Codes/tracking/EagerMOT/data/nuscenes/figure/straight/new_pose.json'
    n = prep_process(fig_dir,label_3d_dir,label_2d_dir,ex_dir,pose='0905')
    #n = 150
    print('PrepPrcess completed...')

    run_on_kitti()
    print('MOT completed...')
    
    root_dir = os.path.dirname(os.path.abspath(__file__))
    fig_save_dir = os.path.join(root_dir,'figures','0121_ens','straight')
    label_mot3d_dir = os.path.join(root_dir,'monodetr','data','test','pointgnn_t3_trackrcnn'
        , 'tracking_cleaning_0_3d','0000.txt')
    label_mot2d_dir = os.path.join(root_dir,'monodetr','data','test','pointgnn_t3_trackrcnn'
        , 'tracking_cleaning_0_2d_projected_3d','0000.txt')

    #calib_dir = '/root/Codes/tracking/EagerMOT/sample/data/test/calib/0000.txt'
    #oxts_dir = '/root/Codes/tracking/EagerMOT/sample/data/test/oxts/0000.txt'
    #show_image_with_boxes(n,calib_dir, oxts_dir, label_det_dir, label_mot_dir, fig_dir, fig_save_dir, root_dir, showBEV = False, show2d = False)
    fig_dir = '/root/Codes/tracking/EagerMOT/data/nuscenes/figure/straight'
    show_image_with_boxes(n,ex_dir, label_3d_dir, label_mot3d_dir, label_mot2d_dir,
        fig_dir, fig_save_dir, root_dir, pose='0905',showBEV = False, show2d = True)

