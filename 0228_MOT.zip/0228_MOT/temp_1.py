# ### 1
# import pandas as pd 

# ex_dir = '/root/Codes/tracking/EagerMOT/data/1119_nj/ins_2024-09-13-09-29-14.csv'
# oxts = pd.read_csv(ex_dir)
# oxts = oxts.iloc[3970:3970+1840,:]

# oxts.to_csv('/root/Codes/tracking/EagerMOT/data/1119_nj/traj_split.csv',index=None)

# ### 2
# import numpy as np 

# for i in range(10):
#     data = np.load("/root/Codes/tracking/EagerMOT/sample/data/test/ego_motion/000{}.npy".format(i))
#     print(data.shape)

### 3
import numpy as np
import pandas as pd 
import os
label_filename = "/root/Codes/tracking/EagerMOT/sample/3dlabel/0000.txt"
lines = [line.rstrip() for line in open(label_filename)]
for idx in range(153): 
    idx_data = [line for line in lines if line.split(" ")[0] == str(idx)]
    with open ("/root/Codes/tracking/EagerMOT/sample/3dlabel/0000/{:06d}.txt".format(idx), "w") as f:
        for obj_data in idx_data:
            info = obj_data.split(" ") 
            frame_id = int(info[0])
            obj_id = int(info[1])
            obj_type = info[2]
            #truncated = float(info[3])
            #occluded = int(info[4])
            #alpha = float(info[5])
            if obj_type in ["Car","Van"]:
                obj_type = "Car"
            elif obj_type in ["Pedestrian","Cyclist"]:
                #obj_type = "Cone"
                if idx <70:
                    obj_type = "Pedestrian"
                else:
                    obj_type = "Cone"
            else:
                continue                
            bbox = [float(i) for i in info[6:10]]
            dim = [float(i) for i in info[10:13]]
            loc = [float(i) for i in info[13:16]]
            rot_y = float(info[16])
            # Car -1 -1 0 180.01015440561133 182.9372594351155 249.98934952456125 208.50019302768396 1.4543732 1.556201 3.626048 -23.646532 2.0763025 43.265907 0.27300078 1.1319479176053484 
            f.write("{} -1 -1 0 {} {} {} {} {} {} {} {} {} {} {} 1.0\n".format(obj_type, bbox[0], bbox[1], bbox[2], bbox[3], dim[0], dim[1], dim[2], loc[0], loc[1], loc[2], rot_y))
            
