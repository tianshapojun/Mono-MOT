import os
import cv2 
import numpy as np 
import time 

def h265_to_jpg(): 
    video_path = '/root/Codes/nerf_prep/fig_pre/data/nj/front_wide_2024-09-13-09-29-14.h265'
    cap = cv2.VideoCapture(video_path)
    num = 0 

    while True: 
        ret, frame = cap.read() 
        if ret: 
            cv2.imwrite('./data/1119_nj/origin/{:05d}.png'.format(int(num)),frame)
            num += 1 
        else: 
            break
    cap.release()
    cv2.destroyAllWindows() 

if __name__ == '__main__': 
    h265_to_jpg()