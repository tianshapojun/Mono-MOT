import numpy as np

import colorsys
from typing import Sequence, Iterable, Optional
from math import ceil

import cv2
import matplotlib.pyplot as plt
#import open3d as o3d
import numpy as np
import glob
import os
#import mayavi.mlab as mlab
import pandas as pd
import torch
import json

er = 6378137. # average earth radius at the equator

def latlonToMercator(lat,lon,scale):
    ''' converts lat/lon coordinates to mercator coordinates using mercator scale '''

    mx = scale * lon * np.pi * er / 180
    my = scale * er * np.log( np.tan((90+lat) * np.pi / 360) )
    return mx,my

def latToScale(lat):
    ''' compute mercator scale from latitude '''
    scale = np.cos(lat * np.pi / 180.0)
    return scale

def convertOxtsToPose(oxts):
    ''' converts a list of oxts measurements into metric poses,
    starting at (0,0,0) meters, OXTS coordinates are defined as
    x = forward, y = right, z = down (see OXTS RT3000 user manual)
    afterwards, pose{i} contains the transformation which takes a
    3D point in the i'th frame and projects it into the oxts
    coordinates with the origin at a lake in Karlsruhe. '''
    
    # origin in OXTS coordinate
    # origin_oxts = [48.9843445, 8.4295857] # lake in Karlsruhe
    origin_oxts = oxts[0,:2]
    
    # compute scale from lat value of the origin
    scale = latToScale(origin_oxts[0])
    #print(origin_oxts[0])
    
    # origin in Mercator coordinate
    ox,oy = latlonToMercator(origin_oxts[0],origin_oxts[1],scale)
    origin = np.array([ox, oy, oxts[0,2]])

    #scale = latToScale(oxts[0,0])
    #ox,oy = latlonToMercator(oxts[0,0],oxts[0,1],scale)
    #origin = np.array([ox, oy, oxts[0,2]])
    
    pose = []
    
    # for all oxts packets do
    for i in range(len(oxts)):
        
        # if there is no data => no pose
        if not len(oxts[i]):
            pose.append([])
            continue
    
        # translation vector
        tx, ty = latlonToMercator(oxts[i,0],oxts[i,1],scale)
        t = np.array([tx, ty, oxts[i,2]])
    
        # rotation matrix (OXTS RT3000 user manual, page 71/92)
        rx = oxts[i,3] # roll
        ry = oxts[i,4] # pitch
        rz = oxts[i,5] # heading 
        Rx = np.array([[1,0,0],[0,np.cos(rx),-np.sin(rx)],[0,np.sin(rx),np.cos(rx)]]) # base => nav  (level oxts => rotated oxts)
        Ry = np.array([[np.cos(ry),0,np.sin(ry)],[0,1,0],[-np.sin(ry),0,np.cos(ry)]]) # base => nav  (level oxts => rotated oxts)
        Rz = np.array([[np.cos(rz),-np.sin(rz),0],[np.sin(rz),np.cos(rz),0],[0,0,1]]) # base => nav  (level oxts => rotated oxts)
        R  = np.matmul(np.matmul(Rz, Ry), Rx)
        
        # normalize translation
        t = t-origin
            
        # add pose
        pose.append(np.vstack((np.hstack((R,t.reshape(3,1))),np.array([0,0,0,1]))))
    
    return pose

class Object3d_simple(object):
    """ 3d object label """

    def __init__(self, label_file_line):
        data = label_file_line.split(" ")
        data = data[3:] + [data[2]]
        data[1:] = [float(x) for x in data[1:]]  
        self.type = data[0]
        self.h = data[1]  # box height
        self.w = data[2]  # box width
        self.l = data[3]  # box length (in meters)
        self.t = (data[4], data[5], data[6])  # location (x,y,z) in camera coord.
        self.ry = data[7]  # yaw angle (around Y-axis in camera coordinates) [-pi..pi]
        self.uid = int(data[-1])

def get_file_names(folder_path):
    return [item for item in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, item))]

def inverse_rigid_trans(Tr):
    """ Inverse a rigid body transform matrix (3x4 as [R|t])
        [R'|-R't; 0|1]
    """
    inv_Tr = np.zeros_like(Tr)  # 3x4
    inv_Tr[0:3, 0:3] = np.transpose(Tr[0:3, 0:3])
    inv_Tr[0:3, 3] = np.dot(-np.transpose(Tr[0:3, 0:3]), Tr[0:3, 3])
    return inv_Tr

def qt2rot(tvec,qvec):
    rt_matrix = np.zeros((3,4))
    rt_matrix[:3,:3] = np.array([
        [1 - 2 * qvec[2]**2 - 2 * qvec[3]**2,
         2 * qvec[1] * qvec[2] - 2 * qvec[0] * qvec[3],
         2 * qvec[3] * qvec[1] + 2 * qvec[0] * qvec[2]],
        [2 * qvec[1] * qvec[2] + 2 * qvec[0] * qvec[3],
         1 - 2 * qvec[1]**2 - 2 * qvec[3]**2,
         2 * qvec[2] * qvec[3] - 2 * qvec[0] * qvec[1]],
        [2 * qvec[3] * qvec[1] - 2 * qvec[0] * qvec[2],
         2 * qvec[2] * qvec[3] + 2 * qvec[0] * qvec[1],
         1 - 2 * qvec[1]**2 - 2 * qvec[2]**2]])
    rt_matrix[:3,3] = tvec 
    return rt_matrix 

def get_objs4cam(objects,c2w,c2v):
    boxes_3d_cam = np.zeros((len(objects),8,3))
    for idx,obj in enumerate(objects):
        tf_matrix = np.array([[np.cos(obj.ry),-np.sin(obj.ry),0,obj.t[0]]
                        ,[np.sin(obj.ry),np.cos(obj.ry),0,obj.t[1]]
                        ,[0,0,1,obj.t[2]]])
        l = obj.l
        w = obj.w
        h = obj.h
        x_corners = [l / 2, l / 2, -l / 2, -l / 2
                    ,l / 2, l / 2 + 1.0, 0
                    ,l / 2, l / 2, -l / 2, -l / 2]
        z_corners = [h/2, h/2, h/2, h/2
                        , 0, 0, -h/2
                        , -h/2, -h/2, -h/2, -h/2]
        y_corners = [w / 2, -w / 2, -w / 2, w / 2
                    , 0, 0, 0                
                    , w / 2, -w / 2, -w / 2, w / 2]
        ones = [1,1,1,1,1,1,1,1,1,1,1]
        corners_3d = np.vstack([x_corners, y_corners, z_corners,ones])
        box3d_pts_3d_world = np.dot(tf_matrix[:3,:4],corners_3d).T
        pts_3d_extend = np.hstack((box3d_pts_3d_world[[0,1,2,3,7,8,9,10],:3], np.ones((8, 1))))
        w2c = inverse_rigid_trans(c2w[:3,:4])
        pts_3d_c = np.dot(pts_3d_extend,np.transpose(w2c))
        pts_3d_c = np.dot(pts_3d_c,np.transpose(np.array([[0,0,1],[-1,0,0],[0,-1,0]])))
        pts_3d_c_extend = np.hstack((pts_3d_c, np.ones((8, 1))))
        pts_3d_v = np.dot(pts_3d_c_extend,np.transpose(c2v))
        boxes_3d_cam[idx] = pts_3d_c
    return boxes_3d_cam

def draw_gt_boxes3d(gt_boxes3d, fig, color=(1,1,1), line_width=2, draw_text=False, text_scale=(1,1,1), color_list=None):
    ''' Draw 3D bounding boxes
    Args:
        gt_boxes3d: numpy array (n,8,3) for XYZs of the box corners
        fig: mayavi figure handler
        color: RGB value tuple in range (0,1), box line color
        line_width: box line width
        draw_text: boolean, if true, write box indices beside boxes
        text_scale: three number tuple
        color_list: a list of RGB tuple, if not None, overwrite color.
    Returns:
        fig: updated fig
    ''' 
    num = len(gt_boxes3d)
    for n in range(num):
        b = gt_boxes3d[n]
        if color_list is not None:
            color = color_list[n] 
        if draw_text: mlab.text3d(b[4,0], b[4,1], b[4,2], '%d'%n, scale=text_scale, color=color, figure=fig)
        for k in range(0,4):
            #http://docs.enthought.com/mayavi/mayavi/auto/mlab_helper_functions.html
            i,j=k,(k+1)%4
            mlab.plot3d([b[i,0], b[j,0]], [b[i,1], b[j,1]], [b[i,2], b[j,2]], color=color, tube_radius=None, line_width=line_width, figure=fig)

            i,j=k+4,(k+1)%4 + 4
            mlab.plot3d([b[i,0], b[j,0]], [b[i,1], b[j,1]], [b[i,2], b[j,2]], color=color, tube_radius=None, line_width=line_width, figure=fig)

            i,j=k,k+4
            mlab.plot3d([b[i,0], b[j,0]], [b[i,1], b[j,1]], [b[i,2], b[j,2]], color=color, tube_radius=None, line_width=line_width, figure=fig)
    #mlab.show(1)
    #mlab.view(azimuth=180, elevation=70, focalpoint=[ 12.0909996 , -1.04700089, -2.03249991], distance=62.0, figure=fig)
    return fig

def draw_objs4cam_pcds(mot_label_filename,pcds_dir,ex_dir):
    idx = 323
    lines = [line.rstrip() for line in open(mot_label_filename)]
    objects = [Object3d_simple(line) for line in lines if line.split(" ")[0] == str(idx) and line.split(" ")[2] != str(-1)]

    oxts = pd.read_csv(ex_dir)
    oxts = oxts[['lat','lon','altitude','roll','pitch','azimuth']]
    oxts['azimuth'] = (360-oxts['azimuth'])/360*2*np.pi
    oxts['roll'] = oxts['roll']/360*2*np.pi
    oxts['pitch'] = oxts['pitch']/360*2*np.pi
    oxts = np.array(oxts)
    poses = convertOxtsToPose(oxts)
    c2i = np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]])
    c2w = poses[int(10*idx)] @ c2i
    c2v = qt2rot([-0.04320845718581837,-0.1524808919051858,-0.27736788316761224],[-0.004147998234725403,-0.7002833728790873,0.7138522394953019,0.0009858738641760015])
    c2v = qt2rot([3.10285700e-02,-2.56307810e-01,-3.47812220e-01],[0.00090832,-0.69391413,0.7200441,-0.00434068])     
    print(c2v)
    boxes_3d_cam = get_objs4cam(objects,c2w,c2v)

    file_index = 1
    filenames = sorted(get_file_names(pcds_dir))
    filename = os.path.join(pcds_dir,filenames[file_index]) 
    pcd_type = o3d.t.io.read_point_cloud(filename)
    pcd_positions = o3d.t.io.read_point_cloud(filename).point["positions"].numpy()
    pcd_intensity = o3d.t.io.read_point_cloud(filename).point["intensity"].numpy()
    pointcloud = np.concatenate((pcd_positions[:,],pcd_intensity), axis=1)
    print(len(pointcloud))
    if len(pointcloud) ==0: 
        return
    pointcloud = pointcloud @ np.array([[0,-1,0,0],[1,0,0,0],[0,0,1,0],[0,0,0,1]]).T

    rg = [-50, -50, -5, 50, 50, 3]
    pointcloud = pointcloud[(pointcloud[:,0]>=rg[0]) & (pointcloud[:,0]<=rg[3])]
    pointcloud = pointcloud[(pointcloud[:,1]>=rg[1]) & (pointcloud[:,1]<=rg[4])]
    pointcloud = pointcloud[(pointcloud[:,2]>=rg[2]) & (pointcloud[:,2]<=rg[5])]
    x = pointcloud[:, 0]  # x position of point
    y = pointcloud[:, 1]  # y position of point
    z = pointcloud[:, 2]  # z position of point
    print(pointcloud.shape)
    
    print(file_index,x.max(),x.min(),y.max(),y.min(),z.max(),z.min())

    
    #r = pointcloud[:, 3]  # reflectance value of point
    #print(r.max(),r.min())
    d = np.sqrt(x ** 2 + y ** 2)  # Map Distance from sensor
    
    #degr = np.degrees(np.arctan(z / d))
    
    vals = 'height'
    if vals == "height":
        col = z#(z-z.min())/(z.max()-z.min())
    else:
        col = d
    
    fig = mlab.figure(bgcolor=(0, 0, 0), size=(400, 400))
    nodes = mlab.points3d(x, y, z,
                        col,  # Values used for Color
                        mode="point",
                        colormap='spectral',  # 'bone', 'copper', 'gnuplot','spectral'
                        # color=(0, 1, 0),   # Used a fixed (r,g,b) instead
                        #resolution = 20,
                        scale_mode='none',
                        figure=fig,
                        )
    draw_gt_boxes3d(boxes_3d_cam,fig)
    mlab.show()

def check_numpy_to_torch(x):
    if isinstance(x, np.ndarray):
        return torch.from_numpy(x).float(), True
    return x, False


def rotate_points_along_z(points, angle):
    """
    Args:
        points: (B, N, 3 + C)
        angle: (B), angle along z-axis, angle increases x ==> y
    Returns:

    """
    points, is_numpy = check_numpy_to_torch(points)
    angle, _ = check_numpy_to_torch(angle)

    cosa = torch.cos(angle)
    sina = torch.sin(angle)
    zeros = angle.new_zeros(points.shape[0])
    ones = angle.new_ones(points.shape[0])
    rot_matrix = torch.stack((
        cosa,  sina, zeros,
        -sina, cosa, zeros,
        zeros, zeros, ones
    ), dim=1).view(-1, 3, 3).float()
    points_rot = torch.matmul(points[:, :, 0:3], rot_matrix)
    points_rot = torch.cat((points_rot, points[:, :, 3:]), dim=-1)
    return points_rot.numpy() if is_numpy else points_rot


def boxes_to_corners_3d(boxes3d):
    """
        7 -------- 4
       /|         /|
      6 -------- 5 .
      | |        | |
      . 3 -------- 0
      |/         |/
      2 -------- 1
    Args:
        boxes3d:  (N, 7) [x, y, z, dx, dy, dz, heading], (x, y, z) is the box center

    Returns:
    """

    boxes3d, is_numpy = check_numpy_to_torch(boxes3d)

    #template = boxes3d.new_tensor((
        #[1, 1, -1], [1, -1, -1], [-1, -1, -1], [-1, 1, -1],
        #[1, 1, 1], [1, -1, 1], [-1, -1, 1], [-1, 1, 1],
    #)) / 2
    template = boxes3d.new_tensor((
        [1, 1, 0], [1, -1, 0], [-1, -1, 0], [-1, 1, 0],
        [1, 1, 2], [1, -1, 2], [-1, -1, 2], [-1, 1, 2],
    )) / 2

    corners3d = boxes3d[:, None, 3:6].repeat(1, 8, 1) * template[None, :, :]
    corners3d = rotate_points_along_z(corners3d.view(-1, 8, 3), boxes3d[:, 6]).view(-1, 8, 3)
    corners3d += boxes3d[:, None, 0:3]

    return corners3d.numpy() if is_numpy else corners3d

def draw_projected_box3d(image, qs, color=(0, 255, 0), thickness=2):
    """ Draw 3d bounding box in image
        qs: (8,3) array of vertices for the 3d box in following order:
            1 -------- 0
           /|         /|
          2 -------- 3 .
          | |        | |
          . 5 -------- 4
          |/         |/
          6 -------- 7
    """
    qs = qs.astype(np.int32)
    for k in range(0, 4):
        # Ref: http://docs.enthought.com/mayavi/mayavi/auto/mlab_helper_functions.html
        i, j = k, (k + 1) % 4
        # use LINE_AA for opencv3
        # cv2.line(image, (qs[i,0],qs[i,1]), (qs[j,0],qs[j,1]), color, thickness, cv2.CV_AA)
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
        i, j = k + 4, (k + 1) % 4 + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)

        i, j = k, k + 4
        cv2.line(image, (qs[i, 0], qs[i, 1]), (qs[j, 0], qs[j, 1]), color, thickness)
    return image

def draw_objs4pcd_cam(pcd_label_dir,fig_dir):
    #idx = 318
    idx = 149
    filenames = sorted(os.listdir(pcd_label_dir))
    print(filenames[idx])
    with open(pcd_label_dir+'/{}'.format(filenames[idx]), 'r') as f:
        bbox = json.loads(f.read())
    bb3d = np.array(bbox['bboxes_3d'])
    

    #idx = 323
    idx = 154
    images = glob.glob(os.path.join(fig_dir, '*.jpg'))
    images = sorted(images)
    print(images[idx])
    img = cv2.imread(images[idx])

    if len(bb3d)>0:     
        points = boxes_to_corners_3d(bb3d)
        #(np.array(bbox['labels_3d'])<5),[0,1,2,3,4,8,9]
        #& (np.array(bbox['bboxes_3d'])[:,0]> dis) 
        points = points[(np.array([ele in [0,1,2,3,4,8,9] for ele in bbox['labels_3d']])) & (np.array(bbox['scores_3d']) > 0.5)   ]
        for point in points: 
            #point += [3.10285700e-02,-2.56307810e-01,-3.47812220e-01]
            print(point)
            point = np.dot(point,np.transpose(np.array([[0,-1,0],[0,0,-1],[1,0,0]])))
            if min(point[:,2]) < 1e-6: 
                    continue
            pts_2d = np.dot(point, np.transpose(np.array(
                [[1918.32,0,1866.3],[0,1920.7,1096.6],[0,0,1]]
            )))
            pts_2d[:, 0] /= pts_2d[:, 2]
            pts_2d[:, 1] /= pts_2d[:, 2]
            img = draw_projected_box3d(img, pts_2d, color=(0, 0, 255))
    cv2.imwrite('./aaa.png',img)


if __name__ == '__main__':
    #draw_objs4cam_pcds('./output_post.txt','./pcds','./ins_2024-09-13-09-29-14.csv')
    draw_objs4pcd_cam('../data/1119_nj/20240913_092914','../data/origin')