import numpy as np
import pandas as pd 
import os 
from tqdm import tqdm

def post_process(objs_dict, out_file, freq = 10):
    column_names = ['frame','ts','UID','type','h','w','l','x','y','z','yaw','conf']
    outs = pd.DataFrame(columns = column_names)
    for key,value in objs_dict.items():
        data_df = pd.DataFrame(value,columns = column_names)
        ex_df = pd.DataFrame(columns = column_names)
        for i in range(len(data_df)-1): 
            begin = data_df['frame'].iloc[i]
            end = data_df['frame'].iloc[i+1]
            if end - begin ==1:
                continue
            ts_step = 1000/freq
            temp = pd.DataFrame([[begin + j
                    , int(data_df['ts'].iloc[i]+ ts_step * j)
                    , int(data_df['UID'].iloc[i])
                    , data_df['type'].iloc[i]
                    , data_df['h'].mean(), data_df['w'].mean(), data_df['l'].mean()
                    , np.NaN, np.NaN, np.NaN, np.NaN, -1] for j in range(1, end - begin)],columns=column_names)
            temp  = pd.concat([data_df.iloc[[i]],temp,data_df.iloc[[i+1]]])
            temp['type'] = 0
            temp.interpolate(method="linear", inplace=True)
            ## 1203 
            temp['type'] = data_df['type'].iloc[i]
            if len(ex_df) == 0: 
                ex_df = temp.iloc[1:-1,:]
            else: 
                ex_df = pd.concat([ex_df,temp.iloc[1:-1,:]])
        if ex_df.shape[0]>0:
            ex_df = pd.concat([data_df,ex_df])
            ex_df = ex_df.sort_values(by='frame')
            ex_df.reset_index(drop = True,inplace = True)
            ex_df['vx'] = 0.
            ex_df['vy'] = 0.
            ex_df.iloc[0,-1] = 10
            for i in range(len(ex_df)-1): 
                ex_df.iloc[i,-2] = 1000 * (ex_df['x'].iloc[i+1] - ex_df['x'].iloc[i])/(ex_df['ts'].iloc[i+1] - ex_df['ts'].iloc[i])
                ex_df.iloc[i,-1] = 1000 * (ex_df['y'].iloc[i+1] - ex_df['y'].iloc[i])/(ex_df['ts'].iloc[i+1] - ex_df['ts'].iloc[i])
            outs = pd.concat([outs,ex_df])
        else: 
            data_df['vx'] = 0.
            data_df['vy'] = 0.
            for i in range(len(data_df)-1): 
                data_df.iloc[i,-2] = 1000 * (data_df['x'].iloc[i+1] - data_df['x'].iloc[i])/(data_df['ts'].iloc[i+1] - data_df['ts'].iloc[i])
                data_df.iloc[i,-1] = 1000 * (data_df['y'].iloc[i+1] - data_df['y'].iloc[i])/(data_df['ts'].iloc[i+1] - data_df['ts'].iloc[i])
            if len(outs) == 0:
                outs = data_df.copy()
            else:
                outs = pd.concat([outs,data_df])
    with open(out_file,'w') as f: 
        for out in outs.values: 
            for element in out: 
                f.write(str(element) + ' ')
            f.write('\n')

        