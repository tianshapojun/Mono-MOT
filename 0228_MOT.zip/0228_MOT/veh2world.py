import numpy as np
import pandas as pd
import json

er = 6378137.  # average earth radius at the equator


def latlonToMercator(lat, lon, scale):
    ''' converts lat/lon coordinates to mercator coordinates using mercator scale '''

    mx = scale * lon * np.pi * er / 180
    my = scale * er * np.log(np.tan((90 + lat) * np.pi / 360))
    return mx, my


def latToScale(lat):
    ''' compute mercator scale from latitude '''
    scale = np.cos(lat * np.pi / 180.0)
    return scale


def convertOxtsToPose(oxts):
    ''' converts a list of oxts measurements into metric poses,
    starting at (0,0,0) meters, OXTS coordinates are defined as
    x = forward, y = right, z = down (see OXTS RT3000 user manual)
    afterwards, pose{i} contains the transformation which takes a
    3D point in the i'th frame and projects it into the oxts
    coordinates with the origin at a lake in Karlsruhe. '''

    # origin in OXTS coordinate
    # origin_oxts = [48.9843445, 8.4295857] # lake in Karlsruhe
    origin_oxts = oxts[0, :2]

    # compute scale from lat value of the origin
    scale = latToScale(origin_oxts[0])
    #print(origin_oxts[0])

    # origin in Mercator coordinate
    ox, oy = latlonToMercator(origin_oxts[0], origin_oxts[1], scale)
    origin = np.array([ox, oy, oxts[0, 2]])

    #scale = latToScale(oxts[0,0])
    #ox,oy = latlonToMercator(oxts[0,0],oxts[0,1],scale)
    #origin = np.array([ox, oy, oxts[0,2]])

    pose = []

    # for all oxts packets do
    for i in range(len(oxts)):

        # if there is no data => no pose
        if not len(oxts[i]):
            pose.append([])
            continue

        # translation vector
        tx, ty = latlonToMercator(oxts[i, 0], oxts[i, 1], scale)
        t = np.array([tx, ty, oxts[i, 2]])

        # rotation matrix (OXTS RT3000 user manual, page 71/92)
        rx = oxts[i, 3]  # roll
        ry = oxts[i, 4]  # pitch
        rz = oxts[i, 5]  # heading
        Rx = np.array([[1, 0, 0], [0, np.cos(rx), -np.sin(rx)],
                       [0, np.sin(rx), np.cos(rx)]])  # base => nav  (level oxts => rotated oxts)
        Ry = np.array([[np.cos(ry), 0, np.sin(ry)], [0, 1, 0],
                       [-np.sin(ry), 0, np.cos(ry)]])  # base => nav  (level oxts => rotated oxts)
        Rz = np.array([[np.cos(rz), -np.sin(rz), 0], [np.sin(rz), np.cos(rz), 0],
                       [0, 0, 1]])  # base => nav  (level oxts => rotated oxts)
        R = np.matmul(np.matmul(Rz, Ry), Rx)

        # normalize translation
        t = t - origin

        # add pose
        pose.append(np.vstack((np.hstack((R, t.reshape(3, 1))), np.array([0, 0, 0, 1]))))

    return pose




"""
pose = pose[0:581][-184:]
此处的pose为原始输入图片中的184张图相应的位姿矩阵，若是使用1hz的截取，则需要在除以10，即pose = pose[0:581][-184:][::10]
"""
def pose_downsample(pose):
    pose = pose[::10]
    #pose = pose[0:581][-184:][::10]
    return pose


def load_lane_file(lane_dir):
    lane_lines = []
    with open(lane_dir, 'r') as f:
        for line in f:
            try:
                lane_data = json.loads(line.strip())
                lane_lines.append(lane_data)
            except json.JSONDecodeError:
                continue
    return lane_lines


def inverse_rigid_trans(T):
    """
    计算刚体变换矩阵的逆
    输入:
        T: 4x4 刚体变换矩阵
    输出:
        T_inv: 4x4 逆刚体变换矩阵
    """
    T_inv = np.zeros_like(T)
    T_inv[:3, :3] = T[:3, :3].T  # 旋转矩阵取转置
    T_inv[:3, 3] = -np.dot(T[:3, :3].T, T[:3, 3])  # 平移向量反变换
    T_inv[3, 3] = 1
    return T_inv


cam_pitch = 0.0007296
cam_height = 1.793


# k = np.array([[1918.32, 0, 1866.3], [0, 1920.7, 1096.6], [0, 0, 1]])
def projection_c2v(cam_pitch, cam_height, ):
    P_v2c = np.array([[1, 0, 0, 0],
                      [0, np.cos(np.pi / 2 + cam_pitch), -np.sin(np.pi / 2 + cam_pitch), cam_height],
                      [0, np.sin(np.pi / 2 + cam_pitch), np.cos(np.pi / 2 + cam_pitch), 0]])
    P_c2v = np.linalg.inv(np.vstack([P_v2c, np.array([0, 0, 0, 1])]))

    return P_c2v[:3, :]


def v2w(lane, poses, new_lane_dir):
    poses = np.array(poses)

    # for frame_idx, frame_data in enumerate(lane):
    #     pose = poses[frame_idx]
    #     world_lane_lines = []
    #
    #     for lane in frame_data["lane_lines"]:
    #         world_xyz = []
    #
    #         for point in lane["xyz"]:
    #             point_h = np.array([point[0], point[1], point[2], 1])
    #             transformed_point_h = np.dot(pose, point_h)
    #             world_xyz.append(transformed_point_h[:3].tolist())
    #
    #         world_lane_lines.append({
    #             "xyz":world_xyz,
    #             "laneLines_prob": lane["laneLines_prob"],
    #             "category": lane["category"],
    #             "lane_id": lane["lane_id"],
    #         })
    #
    #     frame_data["world_lane"] = world_lane_lines
    #
    #     with open(new_lane_dir, 'w') as output_file:
    #         json.dump(frame_data, output_file, indent=4)
    with open(new_lane_dir, 'wb') as output_file:
        # world_poses = []
        for frame_idx, frame_data in enumerate(lane):
            # world_pose = {
            #     "file_path": frame_data['file_path'],
            #     "pose": poses[frame_idx].tolist()
            # }
            # world_poses.append(world_pose)
            pose = poses[frame_idx]
            world_lane_lines = []
            camera_lane_lines = []

            for lane in frame_data["lane_lines"]:
                world_xyz = []
                if "xyz" in lane:
                    # 车辆坐标系转相机坐标系
                    temp = np.array(lane['xyz'])
                    temp = np.concatenate((temp, np.ones((temp.shape[0], 1))), axis=1)
                    c2v = np.array([
                        [9.99990473e-01, 1.72312796e-03, -4.01059771e-03, 0.00000000e+00],
                        [4.01378684e-03, -1.85132558e-03, 9.99990231e-01, 0.00000000e+00],
                        [1.71568621e-03, -9.99996802e-01, -1.85822421e-03, 2.11586978e+00],
                        [0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 1.00000000e+00]
                    ])
                    v2c = inverse_rigid_trans(c2v)
                    v2c[3, 3] = 1
                    temp_camera = temp @ np.transpose(v2c)
                    temp_camera[:, 1] = temp_camera[:, 1] / 2.11554 * 1.793
                    # 相机坐标系转车辆坐标系
                    P_v2c = projection_c2v(cam_pitch, cam_height)
                    temp_vehicle = temp_camera @ np.transpose(P_v2c)
                    lane_point_vehicle = temp_vehicle[:, :3]

                    # 车辆坐标系转世界坐标系
                    for point in lane_point_vehicle:
                        point_h = np.array([point[0], point[1], point[2], 1])
                        transformed_point_h = np.dot(pose, point_h)
                        world_xyz.append(transformed_point_h[:3].tolist())

                    world_lane_lines.append({
                        "xyz": world_xyz,
                        "laneLines_prob": lane["laneLines_prob"],
                        "category": lane["category"],
                    })
            
            frame_data["world_lane"] = world_lane_lines

            #output_file.write(json.dumps(frame_data) + "\n")
            output_file.write(json.dumps(frame_data).encode('utf-8'))
            output_file.write('\n'.encode('utf-8'))
            #json.dump(frame_data,output_file)
        # with open(r"D:\datasets\nanjing\pose.json", 'a') as f:
        #     json.dump(world_poses, f, indent=4)


'''
ex_dir:传感器相关参数，无需更改
lane_dir：推理得到车道线json文件
new_lane_dir：生成世界坐标系后的新json保存位置
'''

ex_dir = '/root/Codes/tracking/EagerMOT/data/1119_nj/1226_pb/ins_2024-09-13-09-29-14_1840_new.csv'
lane_dir = '/root/Codes/tracking/EagerMOT/data/1119_nj/1226_pb/lane3d_prediction.json'
new_lane_dir = '/root/Codes/tracking/EagerMOT/data/1119_nj/1226_pb/lane3d_try.json'
oxts = pd.read_csv(ex_dir)
oxts = oxts[['lat', 'lon', 'altitude', 'roll', 'pitch', 'azimuth']]
oxts['azimuth'] = (360 - oxts['azimuth']) / 360 * 2 * np.pi
oxts['roll'] = oxts['roll'] / 360 * 2 * np.pi
oxts['pitch'] = oxts['pitch'] / 360 * 2 * np.pi
oxts = np.array(oxts)
poses = convertOxtsToPose(oxts)
poses = pose_downsample(poses)
#load_lane_file(lane_dir)
lane = load_lane_file(lane_dir)
lane.sort(key = lambda x: x['file_path'].split('/')[-1])
v2w(lane, poses, new_lane_dir)
