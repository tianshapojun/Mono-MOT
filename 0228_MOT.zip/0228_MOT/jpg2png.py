import os
import shutil
import glob
import numpy as np
import json 
import pandas as pd
import cv2

fig_dir = '/root/Codes/tracking/EagerMOT/data/1119_nj/proj'
save_dir = fig_dir+'_png'
images = glob.glob(os.path.join(fig_dir, '*.jpg'))
images = sorted(images)

for idx,image in enumerate(images):
    temp = cv2.imread(image)
    cv2.imwrite(os.path.join(save_dir,'{:05d}.png'.format(idx)),temp)